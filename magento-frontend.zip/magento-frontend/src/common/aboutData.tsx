import { useTranslation } from "react-i18next";

export type AboutData = {
  type: string;
  tab: {
    text: string;
    type: string;
  }[];
}[];

function useAboutData() {
  const { t } = useTranslation();
  const PageType: AboutData = [
    {
      type: "about", //品質管理與策略
      tab: [
        { text: t("About_Manage.breadcrumbText3"), type: "Manage" },//360
        { text: t("About_Policy.TitleContentBlock1"), type: "Policy" },
        { text: t("About_Environmental.breadcrumbText3"), type: "Environmental" },//360
        { text: t("About_Certified.TitleContentTitle"), type: "Certified" },
        { text: t("About_Event.breadcrumbText3"), type: "Event" },//360
      ]
    }
  ];
  return PageType;
}

export default useAboutData;
