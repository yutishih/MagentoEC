import React, { useEffect } from "react";
import Layout from "../../component/layout/main";
import Columns from "../../component/columns/main";
import { ColType } from "../../component/columns/interface";
import usePageData from "./pageData";
import "./css.scss";

const DeleteSuccessContent = () => {
  const { content, title } = usePageData();
  const pageName = "AccountDeleteSuccess";

  useEffect(() => {
    const pTag = document.getElementsByTagName("p")
    Array.from(pTag).forEach(element => {
      element.remove();
    });
  }, [])

  return (
    <div className={`${pageName}Content`}>
      <h1 className="mainTitle">{title}</h1>
      <div className="content">{content}</div>
    </div>
  );
};

const AccountDeleteSuccess: React.FC = () => {

  return (
    <Layout>
      <Columns
        type={ColType.OneCol}
        content={<DeleteSuccessContent />}
      />
    </Layout>
  );
};

export default AccountDeleteSuccess;
