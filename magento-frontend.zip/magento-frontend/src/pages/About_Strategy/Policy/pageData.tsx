import { useTranslation } from "react-i18next";
import { TextAlign, BannerType } from "../../../component/banner/interface";
import { I_TemplateLayout } from "../../../templates/TemplateLayout/interface";
import { urlConfig } from "../../../config/urlSetting";

function usePageData() {
  const { t } = useTranslation();
  const PageType: I_TemplateLayout = {
    props: [
      {
        type: "FullBanner",
        data: [
          {
            src: `${urlConfig().s3Url}/Image/hannstar/about/strategy/img_strategy_top_banner.jpg`,
            title: t("About_Policy.bannerText"),
            text: "",
            textAlign: TextAlign.BottomLeft,
            type: BannerType.Main,
          },
        ],
      },
      {
        type: "BreadcrumbsBlock",
        data: [
          {
            title: "",
            breadcrumbsLink: [
              {
                text: t("About_Policy.breadcrumbText1"),
                href: "",
              },
              {
                text: t("About_Policy.breadcrumbText2"),
                href: "",
              },
              {
                text: t("About_Policy.breadcrumbText3"),
                href: "",
              },
            ],
          },
        ],
      },
      {
        type: "AboutTab",
        data: [
          {
            type: "about",
            activeId: 1,
          },
        ],
      },
      {
        type: "TitleContentBlock",
        data: [
          {
            title: `${t('About_Policy.TitleContentBlock1')}`,
            content: `${t('About_Policy.TitleContentBlock2')}`,
          },
        ],
      },
      {
        type: "BannerBlock",
        data: [
          {
            src: `${urlConfig().s3Url}/Image/hannstar/about/strategy/img_strategy_content_banner01.jpg`,
            title: "",
            text: "",
            textAlign: TextAlign.BottomLeft,
          },
        ],
      },
      {
        type: "TitleContentBlock",
        data: [
          {
            title: `${t('About_Policy.TitleContentBlock3')}`,
            content: `${t('About_Policy.TitleContentBlock4')}`,
          },
          {
            title: "",
            content: `${t('About_Policy.TitleContentBlock5')}`,
          },
          {
            title: "",
            content: `${t('About_Policy.TitleContentBlock6')}`,
          },
          {
            title: "",
            content: `${t('About_Policy.TitleContentBlock7')}`,
          },
        ],
      },
      {
        type: "BannerBlock",
        data: [
          {
            src: `${t('About_Policy.banner1')}`,
            title: "",
            text: "",
            textAlign: TextAlign.BottomLeft,
          },
        ],
      },
      {
        type: "SustainabilityGraphics3",
        data: [
          {
            src: `${t('About_Policy.banner2')}`,
            title: `${t('About_Policy.GraphicsTitle1')}`,
            content: `${t('About_Policy.GraphicsContent1')}`,
          },
        ],
      },
    ],
  };

  return PageType;
}

export default usePageData;
