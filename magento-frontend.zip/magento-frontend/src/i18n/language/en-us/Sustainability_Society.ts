export const SustainabilitySociety = {
    bannerTitle: "Society",
    bannerContent:`Only sustainable talents can biuld sustainable enterprises.
    Our goal is to create a sustainable and prosperous society with everyone. `,
    title1:"Social Engagement",
    subTitle1:`HannStar takes actions and gives back to show gratitude to everyone on the land where it is at.
    We co-exist with the local people, culture, and industries in a sustainable manner and hope all of us can grow annd prosper together. ",
    graphics1Title:"Growth and Development`,
    graphics1Title:"Local Digital Development Program",
    graphics1SubTitle:`We began to donate computer hardware
    equipment such as computers, laptops
    and LCD displays since 2015, totaling
    2,717 items over the past 5 years. The
    computer hardware equipment repaired
    by the ASUS Foundation is donated
    to disadvantaged groups for digital
    development programs. In doing this, we
    are able to reduce the gap between cities
    and rural communities while reducing the
    damage to the earth, fulling our corporate
    social responsibility.`,
    graphics2Title:"Support Taiwan Farming Products and Social Care",
    graphics2SubTitle:`To take care of local farmers in Taiwan and support their produce, we ordered 200 boxes of pineapples in 2021 to share with all colleagues.
    We collaborated with National Sun Yat-Sen University (Project USR) to purchase pomelos from local farmers in Tainan and donated them to the cases in "Deliver To The Elders" by Mennonite Social Wellfare Foundation: elders living alone in remote villages in Hualien and disadvantaged families, so they could also feel the care from the society during the Mid-Autumn Festival. Also, we financilly support the Assistive Device Bank of Mennonite Foundation, so that elders with disabilities can enjoy better life quality.`,
    breadcrumbsItem:"Home",
    breadcrumbsItem1:"Sustainability",
    breadcrumbsItem2:"Social Engagement"
  }