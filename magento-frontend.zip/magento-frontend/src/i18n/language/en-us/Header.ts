export const Header = {
  Login:"Sign in",
  Register:"Register",
  MemberCenter:"Member Center",
  SignOut:"Sign out"
};