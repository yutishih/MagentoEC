import { urlConfig } from "../../../config/urlSetting";

export const PaperDisplay_GreenSupplyChain = {
  FullBannerTitle: "Green Product Design",
  FullBannerText: "Design for energy-saving",
  Breadcrumbs1: "Home",
  Breadcrumbs2: "Green Product Design",
  TitleContentBannerTitle1: "Green Supply Chain",
  TitleContentBannerText1:
    "To create a sustainable supply chain, HannStar follows the RBA (Responsible Business Alliance) code of conduct, IECQ QC 080000 hazardous substance process management, Green Product Management (GPM) system, and supplier management and evaluation methods to implement the requirements of green product policies, international regulations and customer product specifications from raw material procurement, product design and internal manufacturing to quality inspection. We believe in corporate growth and an ecological environment and work together with the supply chain to realize a green and sustainable future.",
  banner1: `${urlConfig().s3Url}/Image/paperdisplay/greendesign/pic1EN.png`,
  TitleContentBannerTitle2: "Supplier Cooperation Management",
  TitleContentBannerText2:
    "HannStar integrates the product life management system (PLM), green product management system (GPM), and ERP system to implement toxic and hazardous substances management. Signing the letter of commitment with suppliers such as 'Ethical Commitment' and 'Labor and Moral Risk Assessment Form' to deliver social responsibilities and establish a sustainable supply chain mechanism, standardize and assist raw material and equipment supplier partners to continue to comply with international green regulations, and check and verify with ISO14064 Suppliers' carbon reduction operations, together to create green and sustainable products.",
  banner2: `${urlConfig().s3Url}/Image/paperdisplay/greendesign/pic2EN.png`,
  TitleContentBannerTitle3: "Designed for Sustainability",
  TitleContentBannerText3: `HannStar collaborates with customers and suppliers to design and provide products that meet the world's low-carbon transformation trend. It is also the goal of HannStar research and technology development. Design directions of the paper display are eye protection, energy saving, health, less pollution, and low resource consumption. Furthermore, HannStar connects with suppliers to develop new materials and eco-friendly paper display products innovatively, utilizing no backlight design and reflecting ambient light reflection to present images to achieve low power consumption.`,
  GraphicsCardTitle1: "Reflective Display",
  GraphicsCardText1: `A new reflective display design maximizes the reflectivity of ambient light sources and eliminates energy waste caused by the scattered backlight and environmental interference.`,
  GraphicsCardTitle2: `Low Power Consumption`,
  GraphicsCardText2: `
Utilize QSLFR (Quasi-Static Low Freq. Refresh) technology combined with low-power ICs and special materials by using application-specific integrated circuits (ASICs) significantly lower the energy consumption than that of regular displays.`,
  GraphicsCardTitle3: `Protect Eyes`,
  GraphicsCardText3: `Combined with anti-glare film technology, Cover Lens anti-glare and anti-reflective surface treatment technology, low-reflection optical coating technology, eye protection automatic color temperature adjustment technology, and many other technologies to reduce damage to the eyes.`,
  TitleContentBannerTitle4: "Green Product Development and Process Improvement",
  TitleContentBannerText4: `The research and development of Paper Display products introduce the Task Force on Climate-related Financial Disclosures (TCFD) framework to identify climate risks and opportunities. Starting from the concepts of energy saving, waste reduction, low-carbon emission, and recycling through reflective display technology combined with ultra-low power consumption driver IC, achieving green products with environmental protection, energy saving, and low power consumption, which provides customers with healthier and safer products and services, and achieves commitment to environmental sustainability. In 2021, green product research and development expenses will reach NT$110 million. At the same time, renewable energy and energy storage systems will be used to reduce greenhouse gas emissions in the production process. In 2022, 100% of the FCs machines will use NF3 and SF6 combustion reduction equipment to reduce the emissions generated during the process, reducing the carbon footprint of display paper products.`,
  GraphicsCardTitle4: `Low-temperature Material`,
  GraphicsCardText4: `Develop next-generation, high-efficiency display materials and use low-temperature process, low UV exposure color photoresist raw materials, effectively reducing production time, material consumption, and power consumption.`,
  GraphicsCardTitle5: `Process Refinement`,
  GraphicsCardText5: `Introduce ISO 14064 greenhouse gas emission verification and use the latest manufacturing process to reduce the driving voltage and current required by circuit components and power consumption, improving heat exchange efficiency and reducing energy consumption.`,
  GraphicsCardTitle6: `Low-carbon Manufacturing`,
  GraphicsCardText6: `Nitrogen trifluoride (NF3) and sulfur hexafluoride (SF6), the high global warming potential gases produced during the processes of manufacturing, are disposed of through the exhaust gas combustion equipment that corresponds to the announcements of IPCC. It helps reduce the Scope 1 GHG emissions of the factory and cut the carbon footprint of products.`,
  TitleContentBannerTitle5:
    "Recycling and Reuse Resources to Build a Green Economy",
  TitleContentBannerText5: `
Paper Display practices a green sustainable economy from procurement, manufacturing process, packaging materials, and transportation to reduce environmental impact through resource recycling and reuse. Through the introduction and implementation of ISO 14001 and ISO 45001 systems, in addition to helping improve the efficiency of factory resource use and reduce waste, it also conducts risk evaluation and quantification from environmental aspects and operational safety analysis throughout the product life cycle. By recycling waste liquid and wastewater, carbon emissions and waste pollution can be reduced to fulfill our commitment to environmental protection.`,
  GraphicsCardTitle7: "Waste Recycling",
  GraphicsCardText7: `The color resist recovery system is introduced into the manufacturing process. The excess color resist can be removed from the glass and dropped into the recycling system. In 2021, 38,421 liters of color resist liquid was recovered and reused.`,
  GraphicsCardTitle8: "Wastewater Recycling",
  GraphicsCardText8: `Strengthen the resilience and adaptability of water resources management. Through the reduction of process water in the factory and the recycling of end-of-pipe wastewater, the recirculating water volume in 2021 will reach 9,906 million liters, and the drainage volume of the entire factory area will decrease by 8.43% compared with last year.`,
  GraphicsCardTitle9: "Local Procurement",
  GraphicsCardText9: `
HannStar implements local procurement to reduce carbon emissions during transport and environmental impact. In 2021, the proportion of local procurement achieved 86%, which is good for the local economy and the environment.`,
  GraphicsCardTitle10: "Low Carbon Transport",
  GraphicsCardText10: `Recycling the aprons and trays reduces the unnecessary waste of materials during the shipping process. In 2021, we recovered a total of 3,000 aprons and 47,490 trays, a recovery rate of 100%.`,
  banner3: `${urlConfig().s3Url}/Image/paperdisplay/greendesign/card7EN.png`,
  banner4: `${urlConfig().s3Url}/Image/paperdisplay/greendesign/card8_en.png`,
  banner5: `${urlConfig().s3Url}/Image/paperdisplay/greendesign/081.png`,
  banner6: `${urlConfig().s3Url}/Image/paperdisplay/greendesign/082EN.png`,
};
