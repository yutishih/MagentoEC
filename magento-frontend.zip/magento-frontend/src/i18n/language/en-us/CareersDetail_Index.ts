export const CareersDetailIndex = {
  bannerTitle: `Embrace change and create your future.
  Join us to unleash the ubiquitous impact of technology.`,
  bannerContent:``,
  bannerBlockTitle1:`Through constant innovation, 
  Our application of green displays opens a window to make the world a better place with a better life.`,
  bannerContent1:``,
  bannerBlockTitle2:`At HannStar,
  You can create infinite possibilities with your partners.
  Learn about our work culture, environment, and available resources. `,
  bannerContent2:`Work at HannStar.`,
  bannerBlockTitle3:`Are you looking for opportunities to grow and develop your career?
  At HannStar, 
  You have the opportunity to experience the latest applications, 
  Keep pace with advances, and become a better version of yourself.`,
  bannerContent3:`Grow at HannStar.`,
  bannerBlockTitle4:`Join our team and be part of HannStar's veins.
  Fulfill yourself and create the future together.`,
  bannerContent4:`Join HannStar.`,
  breadcrumbsItem1:"Home",
  breadcrumbsItem2:"Recruitment",
}