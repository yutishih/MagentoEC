export const Account_Logout = {
    title:"Sign Out Successfully",
    content: "You have signed out and the page will redirect to the home page in 5 seconds",
    DeleteSuccessTitle:"Your account has been deleted.",
    DeleteSuccessContent: "you will go to our homepage in 5 seconds",
};