export const Account_SendVerifyEmail = {
    sendVerification: "Send Verification Email",
    enterEmail: "Please enter email address to receive verification email.",
    qequired: "Required field. Wrong format, please enter again.",
    verificationletter: "Send Verification Email",
};