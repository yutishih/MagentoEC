export const Account_Personal_Template = {

    breadcrumbsLinkAccountInfo: "Account Information",
    breadcrumbsLinkPersonal: "Personal Portal",
    breadcrumbsLinkAuthority:"Permission Management",
    breadcrumbsLinkEnterprise:"Enterprise Portal",
    breadcrumbsLinkMember:"Member Information",
    breadcrumbsLinkKanban:"Dashboard",
}