export const Account_Newsletter = {
    breadcrumbsLinkFrontPage: "Home Page",
    breadcrumbsLinkMemberCentre:"Member Center",
    breadcrumbsLinkNewsLetter: "email subscription",
    title: "Subscription",
    subTitle: "Mail Type",
    options: "Marketing and product mail",
    saveBtn:"Save"
};