export const About_Strategy = {
    breadcrumbsItem1: "Home",
    breadcrumbsItem2: "About us",
    breadcrumbsItem3: "Management",
  };