export const About_Certification = {
  breadcrumbsItem1: "Home",
  breadcrumbsItem2: "About us",
  breadcrumbsItem3: "Certification and Affirmation",
};
