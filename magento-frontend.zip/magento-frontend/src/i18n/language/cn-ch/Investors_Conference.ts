export const Investors_Conference = {
    breadcrumbsItem1:"首頁",
    breadcrumbsItem2: "法人說明會",
};