export const Investors_Dividend = {
    breadcrumbsItem1:"首頁",
    breadcrumbsItem2: "股利分派",
};