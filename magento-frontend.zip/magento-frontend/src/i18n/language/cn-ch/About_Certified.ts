import { urlConfig } from "../../../config/urlSetting"

export const About_Certified = {
  bannerText:"质量管理与策略",
  breadcrumbText1:"首頁",
  breadcrumbText2:"关于瀚宇彩晶",
  breadcrumbText3:"绿色管理与认证",
  TitleContentTitle:"绿色管理与认证",
  TitleContent:`彩晶深知企业所提供的产品将可能对环境产生极大的影响，因此在产品设计方面除注重用户需求、功能性、及附加价值外，自产品设计的阶段，即以「减少环境负荷」的角度来思考规划。`,
  TitleContent2:`所有供货商都需符合，其规定内容包括省能源、易回收、低毒性、材质标示、包装材等。各供货商须提供合格之产品检验报告，以证明该产品符合「瀚宇彩晶产品环保规格」的要求，并于部品或产品承认前提供给GP管理单位审查，经GP管理单位判定合格后方能使用。`,
  TitleContent3:`欧盟RoHS 2.0指令之因应自欧盟RoHS 指令公告以来，彩晶成立专责GP管理单位，一方面搜集掌握各国相关法规与相关信息，针对各产品线与主要组件供货商进行沟通倡导、制程原物料盘查、转换与确认。经过长期的努力以下下，所有彩晶产品皆已符合欧盟 RoHS 2.0指令。`,
  TitleContent4:`系统认证 彩晶除了立志于环境保护外，更积极导入各项绿色产品系统认证。南京厂于2010年3月取得IECQ QC080000有害物质管理系统认证。台南厂于2019年5月取得SONY Green Partner认证，2019年12月取得IECQ QC080000:2017认证`,
  TitleContent5:`绿色产品管理系统为有效管理合格供货商及材料，降低有害物质风险。瀚宇彩晶于 2012 年更新现有绿色产品管理系统 (GPM)，将供货商管理信息建立其中，并建构规范数据库及物质数据库，除了可以更有效率管理所属材料外，亦可以在最短时间内确认国际法规所规范之最新物质，及客户所提出之产品环保规范。`,
  BannerBlock1:`${urlConfig().s3Url}/Image/hannstar/about/strategy/chart_strategy_mnc_sc.png`,
  TitleContent6:"合格材料管控",
  TitleContent7:"新产品材料供货商，须完成均质拆解检测报告及SDS数据上传，并审核通过。始能成为合格材料，并于每年进行报告更新，以维持其有效状态。",
  BannerBlock2:`${urlConfig().s3Url}/Image/hannstar/about/strategy/chart_strategy_qc_sc.png`,
};
