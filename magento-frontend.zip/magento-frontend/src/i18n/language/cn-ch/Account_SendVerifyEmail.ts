export const Account_SendVerifyEmail = {
    sendVerification: "寄送验证信",
    enterEmail: "请在下方栏位输入邮箱收取验证信。",
    qequired: "必填栏位。输入格式有误，请重新输入。",
    verificationletter: "发送验证信",
};