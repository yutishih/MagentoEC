export const CareersDetailIndex = {
  bannerTitle: "拥抱改变 开创未来与我们一起发挥科技无所不在的影响力",
  bannerContent:``,
  bannerBlockTitle1:`透过不断创新，
  我们透过绿色显示器的应用 
  开启让世界更美好、生活更精采的视窗
   開啟讓世界更美好、生活更精采的視窗`,
  bannerContent1:``,
  bannerBlockTitle2:`在彩晶
  你可以和伙伴一起创造无限可能
  了解我们的工作文化、环境、以及你可善用的资源`,
  bannerContent2:`工作在彩晶`,
  bannerBlockTitle3:`正在寻找成长与发展职涯的机会吗？
  在彩晶，你有机会参与最先进应用，与时俱进，成为更好的自己`,
  bannerContent3:`成长在彩晶`,
  bannerBlockTitle4:`加入我们的团队，形塑彩晶的DNA
  成就自己，一起创造未来`,
  bannerContent4:`加入彩晶`,
  breadcrumbsItem1:"首页",
  breadcrumbsItem2:"人才招募",
}