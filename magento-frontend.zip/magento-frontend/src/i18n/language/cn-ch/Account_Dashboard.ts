export const Account_Dashboard = {
    breadcrumbsLinkFrontPage: "首页",
    breadcrumbsLinkMemberCentre:"会员中心",
    breadcrumbsLinkDashboard: "看板",
    contentTitle: "看板",
    contentTableDate: "日期",
    contentTableNumber: "单号",
    contentTableProject: "项目",
    contentTableProductNo: "产品型号",
    contentTableSchedule: "进度",
    contentTableDetails: "详情",
};