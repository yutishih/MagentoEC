export const Account_Personal_Template = {

    breadcrumbsLinkAccountInfo: "帐户资讯",
    breadcrumbsLinkPersonal: "个人专区",
    breadcrumbsLinkAuthority:"权限管理",
    breadcrumbsLinkEnterprise:"企业专区",
    breadcrumbsLinkMember:"成员资讯",
    breadcrumbsLinkKanban:"看板",
}