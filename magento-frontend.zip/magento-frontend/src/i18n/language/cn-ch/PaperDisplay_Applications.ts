import { urlConfig } from "../../../config/urlSetting";

export const PaperDisplay_Applications = {
    FullBannerTitle:"显示纸科技",
    BreadcrumbsBlock1:"首頁",
    BreadcrumbsBlock2:"显示纸科技",
    ApplicationsTitle:"应用",
    img1:`${urlConfig().s3Url
          }/Image/paperdisplay/technology/icon/cityCN.png`,
    imgHover1: `${urlConfig().s3Url
          }/Image/paperdisplay/technology/icon/cityhoverCN.png`,
    img2:`${urlConfig().s3Url
          }/Image/paperdisplay/technology/icon/edutainmentCN.png`,
    imgHover2:`${urlConfig().s3Url
          }/Image/paperdisplay/technology/icon/edutainmenthoverCN.png`,
    img3:`${urlConfig().s3Url
          }/Image/paperdisplay/technology/icon/retailingCN.png`,
    imgHover3:`${urlConfig().s3Url
          }/Image/paperdisplay/technology/icon/retailinghoverCN.png`,
    img4:`${urlConfig().s3Url
          }/Image/paperdisplay/technology/icon/healthcareCN.png`,
    imgHover4:`${urlConfig().s3Url
          }/Image/paperdisplay/technology/icon/healthcarehoverCN.png`,
    img5:`${urlConfig().s3Url
          }/Image/paperdisplay/technology/icon/IIoTCN.png`,
    imgHover5:`${urlConfig().s3Url
          }/Image/paperdisplay/technology/icon/IIoThoverCN.png`,
  };