export const Footer = {
  privacy:"隐私声明",
  legalnotices:"法律声明",
  siteMap:"网页地图"
};
