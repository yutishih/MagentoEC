export const Investors_Contacts = {
    breadcrumbsItem1:"首頁",
    breadcrumbsItem2: "投資人相關洽詢",
};