export const Account_MemberInfo = {
    breadcrumbsLinkFrontPage: "首页",
    breadcrumbsLinkMemberCentre:"会员中心",
    breadcrumbsLinkMemberInfo: "成员资讯",
    inputEmail: "请输入Email",
    contentTitle: "成员资讯",
    contentLabel: "邀请成员",
    contentBtn: "+邀请", 
    contentTableName: "姓名", 
    contentTableEmail: "邮箱",
    contentTableJobTitle: "职称", 
};