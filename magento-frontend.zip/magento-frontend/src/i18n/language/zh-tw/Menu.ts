export const Menu = {
  about: "關於瀚宇彩晶",
  about_index:"瀚宇彩晶簡介",
  about_team:"瀚宇彩晶團隊",
  about_family:"瀚宇關係企業",
  about_strategy:"品質管理與策略",
  about_certification:"認證與獎項",
  about_stronghold:"全球據點",
  product:"產品",
  company:"企業永續",
  sustainability_csr:"永續管理",
  sustainability_governance:"公司治理",
  sustainability_environment:"綠色創新",
  sustainability_social:"社會共融",
  sustainability_report:"報告書下載",
  sustainability_esg:"永續訊息",
  news_esg:"永續訊息",
  invest:"投資人關係",
  investors_Summary:"公司概況",
  investors_Revenue:"每月營收",
  investors_Report:"財務季報及公司年報",
  investors_Conference:"法人說明會",
  investors_Shareholdermeeting:"股東會資訊",
  investors_Dividend:"股利分派",
  investors_Quote:"股價查詢",
  investors_Contacts:"投資人相關洽詢",
  resources:"人才招募",
  careersDetail_Work:"工作在彩晶",
  careersDetail_Growup:"成長在彩晶",
  careersDetail_Join:"加入彩晶",
  message:"訊息中心",
  news_financial:"投資人關係",
  support:"常見問題",
  paperdisplay_Technology:"顯示紙技術",
  paperdisplay_Applications:"顯示紙應用",
  paperdisplay_GreenProductDesign:"綠色產品設計",
  paperdisplay_ProductsandQuotations:"產品與詢價",
  paperdisplay_News:"訊息中心",
  paperdisplay_Applications_SmartCity:"智慧城市",
  paperdisplay_Applications_SmartRetailing:"智慧零售",
  paperdisplay_Applications_SmartEdutainment:"智慧育樂",
  paperdisplay_Applications_Healthcare:"健康關懷",
  paperdisplay_Applications_IIoT:"智能製造",
  paperdisplay_ProductsandQuotations_FeaturedProducts:"優選產品",
  paperdisplay_ProductsandQuotations_CustomizationService:"客製化服務",

  






};
