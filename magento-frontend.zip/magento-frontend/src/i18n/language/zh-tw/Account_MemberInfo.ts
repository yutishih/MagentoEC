export const Account_MemberInfo = {
    breadcrumbsLinkFrontPage: "首頁",
    breadcrumbsLinkMemberCentre:"會員中心",
    breadcrumbsLinkMemberInfo: "成員資訊",
    inputEmail: "請輸入Email",
    contentTitle: "成員資訊",
    contentLabel: "邀請成員",
    contentBtn: "+邀請", 
    contentTableName: "姓名", 
    contentTableEmail: "郵箱",
    contentTableJobTitle: "職稱 ", 
};