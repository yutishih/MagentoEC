export const About_Team = {
  breadcrumbsItem1: "首頁",
  breadcrumbsItem2: "關於瀚宇彩晶",
  breadcrumbsItem3: "瀚宇彩晶團隊",
};
