import { urlConfig } from "../../../config/urlSetting";

export const PaperDisplay_Applications = {
    FullBannerTitle:"顯示紙科技",
    BreadcrumbsBlock1:"首頁",
    BreadcrumbsBlock2:"顯示紙科技",
    ApplicationsTitle:"應用",
    img1:`${urlConfig().s3Url
          }/Image/paperdisplay/technology/icon/cityCN.png`,
    imgHover1: `${urlConfig().s3Url
          }/Image/paperdisplay/technology/icon/cityhoverTW.png`,
    img2:`${urlConfig().s3Url
          }/Image/paperdisplay/technology/icon/edutainmentTW.png`,
    imgHover2:`${urlConfig().s3Url
          }/Image/paperdisplay/technology/icon/edutainmenthoverTW.png`,
    img3:`${urlConfig().s3Url
          }/Image/paperdisplay/technology/icon/retailingCN.png`,
    imgHover3:`${urlConfig().s3Url
          }/Image/paperdisplay/technology/icon/retailinghoverTW.png`,
    img4:`${urlConfig().s3Url
          }/Image/paperdisplay/technology/icon/healthcareTW.png`,
    imgHover4:`${urlConfig().s3Url
          }/Image/paperdisplay/technology/icon/healthcarehoverTW.png`,
    img5:`${urlConfig().s3Url
          }/Image/paperdisplay/technology/icon/IIoTCN.png`,
    imgHover5:`${urlConfig().s3Url
          }/Image/paperdisplay/technology/icon/IIoThoverTW.png`,
  };