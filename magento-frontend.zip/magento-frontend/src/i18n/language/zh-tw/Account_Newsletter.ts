export const Account_Newsletter = {
    breadcrumbsLinkFrontPage: "首頁",
    breadcrumbsLinkMemberCentre:"會員中心",
    breadcrumbsLinkNewsLetter: "訂閱郵件",
    title: "訂閱郵件",
    subTitle: "郵件類型",
    options: "行銷與產品相關郵件",
    saveBtn:"儲存"
};