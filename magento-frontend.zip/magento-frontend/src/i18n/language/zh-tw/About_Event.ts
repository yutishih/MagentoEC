export const About_Event = {
  bannerText:"品質管理與策略",
  breadcrumbText1:"首頁",
  breadcrumbText2:"關於瀚宇彩晶",
  breadcrumbText3:"綠色產品大事記",
};
