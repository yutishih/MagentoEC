export const Account_Dashboard = {
    breadcrumbsLinkFrontPage: "首頁",
    breadcrumbsLinkMemberCentre:"會員中心",
    breadcrumbsLinkDashboard: "看板",
    contentTitle: "看板",
    contentTableDate: "日期",
    contentTableNumber: "單號",
    contentTableProject: "項目",
    contentTableProductNo: "產品型號",
    contentTableSchedule: "進度",
    contentTableDetails: "詳情",
};