export const About_Environmental = {
  bannerText:"品質管理與策略",
  breadcrumbText1:"首頁",
  breadcrumbText2:"關於瀚宇彩晶",
  breadcrumbText3:"綠色環保",
};
