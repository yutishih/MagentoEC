import { urlConfig } from "../../../config/urlSetting"

export const SustainabilityEnvironmentWeather = {
  bannerTitle: "綠色創新",
  bannerContent:`從綠色產品之設計、供應鏈到生產，秉持企業成長與生態環境共榮的信念，厚植綠色管理於日常營運。`,
  title1:"氣候變遷風險管理",
  title2:"關鍵氣候風險與機會議題因應與管理",
  subTitle1:"面對全球暖化及極端氣候帶來可能的營運衝擊，瀚宇彩晶過去已進行廠區的節能減碳，為進一步了解氣候變遷議題對瀚宇彩晶營運的影響，及強化公司對於氣候風險與機會的鑑別與因應，我們結合內部既有風險管理架構以及氣候相關財務揭露建議（TCFD）框架，由各項氣候風險與機會的對應部門，依據現況與趨勢進行重大氣候相關風險與機會辨識，完成辨識後共同討論擬定全公司氣候相關治理策略，並檢視各項因應議題之對應目標執行狀況，並由最高管理階層統籌監督相關事項運作。",
  breadcrumbsItem:"首頁",
  breadcrumbsItem1:"企業永續",
  breadcrumbsItem2:"氣候變遷風險管理",
  banner1:`${urlConfig().s3Url}/Image/hannstar/sustainability/environment/risk/image358.png`,
  banner2: `${urlConfig().s3Url}/Image/hannstar/sustainability/environment/risk/image363.png`,
  banner3:`${urlConfig().s3Url}/Image/hannstar/sustainability/environment/risk/image364.png`, 
}
  
  