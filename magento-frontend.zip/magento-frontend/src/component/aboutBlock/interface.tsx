export interface I_AboutBlock {
  activeId?: number;
  type: string;
  handleAboutTab?: any;
}
