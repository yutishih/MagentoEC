export interface I_Popup {
    height?: string
}