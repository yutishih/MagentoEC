export interface I_SustainabilityBlock {
  activeId?: number;
  type: string;
  component: string;
  handleSustainabilityTab?: any;
}
