import React from "react";
import { useIsMobile } from "../../hooks";
import { I_ModelViewer } from "./interface";
import "./css.scss";
declare global {
  namespace JSX {
    interface IntrinsicElements {
      ['model-viewer']: any;
    }
  }
}

const fakeHotSpot =[
  {
    text:'1',
    position:'-0.0569m 0.0969m -0.1398m',
    normal:'-0.5829775m 0.2863482m -0.7603565m',
    orbit:'-50.94862deg 84.56856deg 0.06545582m',
    target:'-0.04384604m 0.07348397m -0.1213202m',
  },
  {
    text:'2',
    position:'-0.1997m 0.11766m 0.0056m',
    normal:'-0.4421014m 0.04410423m 0.8958802m',
    orbit:'3.711166deg 92.3035deg 0.04335197m',
    target:'-0.1879433m 0.1157161m -0.01563221m',
  },
  {
    text:'3',
    position:'-0.1997m 0.11766m 0.0056m',
    normal:'-0.4421014m 0.04410423m 0.8958802m',
    orbit:'3.711166deg 92.3035deg 0.04335197m',
    target:'-0.1879433m 0.1157161m -0.01563221m',
  }
];

const ModelViewer: React.FC<I_ModelViewer> = ({
  src,
}) => {
  const isMobile = useIsMobile();
  const modelRef = React.useRef();
  const hotspots = fakeHotSpot;

  const annotationClicked = (annotation: { orbit: any; target: any; }) => {
    console.log("3D模型按鈕點擊!!")
    const modelViewer2 = document.querySelector("#hotspot-camera-view-demo") as any;
    modelViewer2.cameraTarget = annotation.target;
    modelViewer2.cameraOrbit = annotation.orbit;
    // modelViewer2.fieldOfView = '45deg';
  }
  const render_hotSpotBtn =(item:any,i:number)=>{
    return (
      <button 
        className="view-button" 
        slot={`hotspot-${i}`} 
        data-position={item.position}
        data-normal={item.normal} 
        data-orbit={item.orbit}
        data-target={item.target}
        onClick={()=>annotationClicked({
          orbit:item.orbit,
          target:item.target
        })}
      >
        {item.text}
      </button>
    )
  }
  return (
    <model-viewer 
      id="hotspot-camera-view-demo"
      src={src}
      ar 
      shadow-intensity="1" 
      camera-controls 
      ref={(ref: any)=>{
        modelRef.current = ref;
      }}  
    >
      {
        hotspots && 
        hotspots.length>0 &&
        hotspots.map((item,i)=>render_hotSpotBtn(item,i))
      }
    </model-viewer> 
  );
};

export default ModelViewer;
