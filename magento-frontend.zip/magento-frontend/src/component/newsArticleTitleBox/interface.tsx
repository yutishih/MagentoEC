export interface I_NewsArticleTitleBox {
  title?:string,
  date?:string,
  tag?:Array<string>,
}
