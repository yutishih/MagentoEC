export interface I_PlatformEntry {
  data: {
    title: string;
    src: string;
    href: string;
  }[];
}
