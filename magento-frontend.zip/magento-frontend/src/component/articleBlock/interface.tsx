export type I_Props = {
  src: string;
  title: string;
}

export interface I_Article {
  data:I_Props[]
}