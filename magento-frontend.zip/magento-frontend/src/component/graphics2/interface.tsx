export interface I_Graphics2 {
    data: {
        src: string;
        title: string;
        href: string;
    }[];
}